class Case {
    constructor(index, type, coords, coordsSimplified) {
        this.index = index; //the index of the propagation
        this.type = type; //wall, start, end, path, default
        this.coords = coords; //[0, 0, 50, 50] <- the two-first are x,y of top left and the last-two the x,y of bottom-right 
        this.coordsSimplified = coordsSimplified; // [0;0] or [1;0] simple coord of which cases it is
    }
}



document.addEventListener("DOMContentLoaded", () => {

    //base settings
    const rowLength = 5;
    const columnLength = 3;
    //decoration settings
    const wallColor = null;
    const floorColor = null;
    const startColor = null;
    const finishColor = null;
    const pathColor = null;
    //document's elements
    const mainArea = document.getElementById("main_area");
    //document's elements settings
    const mainAreaWidth = null;
    const mainAreaHeight = null;
    //variables
    const buttonCaseStart = document.getElementById("button_case_start");
    const buttonCaseWall = document.getElementById("button_case_wall");
    const buttonCaseEnd = document.getElementById("button_case_end");
    const buttonCaseDefault = document.getElementById("button_case_defaut");
    const buttonPathFinding = document.getElementById("button_case_find_path");
    const cnv = document.getElementById("canvas_area");
    const ctx = cnv.getContext("2d");
    const width = cnv.width;
    const height = cnv.height;
    let cases = [];
    let mapCases = new Map();
    let currentMode = null;
    let numOfWall = 0;
    let numOfStart = 0;
    let numOfEnd = 0;
    let isMouseDown = false;
    const test = "hello";
    //event listener
    cnv.addEventListener("click", mouseClick);
    cnv.addEventListener("mousedown", mouseDown);
    cnv.addEventListener("mousemove", mouseMove);
    cnv.addEventListener("mouseup", mouseUp);
    buttonCaseStart.addEventListener("click", clickCaseStart);
    buttonCaseWall.addEventListener("click", clickCaseWall);
    buttonCaseEnd.addEventListener("click", clickCaseEnd);
    buttonCaseDefault.addEventListener("click", clickCaseDefault);
    buttonPathFinding.addEventListener("click", pathFinding);
    //actual Code
    initialization();

    //functions
    function pathFinding() {
        //fetch the start and end case
        let startCase = null;
        let endCase = null;
        mapCases.forEach((value, key) => {
            if (value.type === "start") {
                startCase = value;
            } else if (value.type === "end") {
                endCase = value;
            }
        });
        //verify if startCase and endCase have been declared
        if (startCase === null || endCase === null) {
            console.log("Beginning Case or End Case hasn't been placed");
            return;
        } else {
            console.log("Start: ", startCase);
            console.log("End: ", endCase);
            console.log("Propagation...");
            propagation(startCase, 0);
        }
        //propagation
        function propagation(crate, previousIndex) {
            //get the x and y of the crate (case)((because "case" as a parameter is not allowed))
            const xy = getXYfromCase(crate);
            //change the startCase index to 0 and the case next to it to one but using local index variable to refer to
            let index = 0;
            //crate est synchronisé à la liste "mapCases" car c'est de là que nous l'avons prise
            crate.index = index;
            let x = 0;
            let y = 0;
            //one-time index increase 
            index++;
            //top-next case's coords
            x = xy.x;
            y = xy.y - 1;

            if (x >= 0 && x < rowLength && y >= 0 && y < columnLength) {//check if not out of grid
                if (mapCases.get(x + ";" + y).index === null) {
                    mapCases.get(x + ";" + y).index = index;
                }


            }

            //right-next case's coords
            x = xy.x + 1;
            y = xy.y;
            if (x >= 0 && x < rowLength && y >= 0 && y < columnLength) {//check if not out of grid
                if (mapCases.get(x + ";" + y).index === null) {
                    mapCases.get(x + ";" + y).index = index;
                }


            }
            //bottom-next case's coords
            x = xy.x;
            y = xy.y + 1;
            if (x >= 0 && x < rowLength && y >= 0 && y < columnLength) {//check if not out of grid
                if (mapCases.get(x + ";" + y).index === null) {
                    mapCases.get(x + ";" + y).index = index;
                }


            }
            //left-next case's coords
            x = xy.x - 1;
            y = xy.y;
            if (x >= 0 && x < rowLength && y >= 0 && y < columnLength) {//check if not out of grid
                if (mapCases.get(x + ";" + y).index === null) {
                    mapCases.get(x + ";" + y).index = index;
                }


            }
            //case's index !== null || key doesn't exist

            console.log(mapCases);

        }
        function getXYfromCase(crate) {
            const x = crate.coordsSimplified.at(0);
            const y = crate.coordsSimplified.at(2);
            return { x: x, y: y };
        }



    }
    function initialization() {
        const caseWidth = width / rowLength;
        const caseHeight = height / columnLength;
        let currentX = 0;
        let currentY = 0;
        ctx.beginPath();
        for (let i = 0; i < rowLength; i++) {
            currentY = 0;
            for (let j = 0; j < columnLength; j++) {
                const coords = [currentX, currentY, currentX + caseWidth, currentY + caseHeight];
                const coordsSimplified = `${i};${j}`;
                const newCase = new Case(null, "default", coords, coordsSimplified);
                mapCases.set(coordsSimplified, newCase);
                ctx.rect(currentX, currentY, currentX + caseWidth, currentY + caseHeight);
                currentY += caseHeight;
            }
            currentX += caseWidth;
        }
        ctx.stroke();
        console.log(mapCases);
    }
    function mouseClick(event) {
        isMouseDown = true;
        mouseMove(event);
        isMouseDown = false;
    }
    function mouseMove(event) {
        if (currentMode === null) return;
        if (!isMouseDown) return;
        if (currentMode === "start") {
            if (numOfStart === 1) return;
        }
        if (currentMode === "end") {
            if (numOfEnd === 1) return;
        }
        const x = event.offsetX;
        const y = event.offsetY;
        mapCases.forEach((value, key) => {
            if (x > value.coords[0] && y > value.coords[1] && x < value.coords[2] && y < value.coords[3]) {
                if (value.type === currentMode) return;

                if (value.type === "start") {
                    numOfStart--;
                } else if (value.type === "end") {
                    numOfEnd--;
                } else if (value.type === "wall") {
                    numOfWall--;
                }

                updateRectColor(value);
                value.type = currentMode;

                console.log("start: ", numOfStart);
                console.log("end: ", numOfEnd);
                console.log("wall: ", numOfWall);
            }
        });
    }
    function updateRectColor(rect) {
        const x = rect.coords[0];
        const y = rect.coords[1];
        const xp = rect.coords[2];
        const yp = rect.coords[3];
        ctx.fillStyle = getRectStyleFromMod(currentMode);
        ctx.fillRect(x + 1, y + 1, xp - x - 2, yp - y - 2);
    }
    function getRectStyleFromMod(mod) {
        if (mod === "start") {
            numOfStart++;
            return "green";
        } else if (mod === "end") {
            numOfEnd++;
            return "red";
        } else if (mod === "wall") {
            numOfWall++;
            return "grey";
        } else if (mod === "default") {

            return "rgb(243, 240, 255)";
        }
    }
    function clickCaseStart() {
        resetButtonsBG();
        if (currentMode === "start") {
            currentMode = null;
            return;
        }
        currentMode = "start";
        updateButtonBG(buttonCaseStart);
    }
    function clickCaseWall() {
        resetButtonsBG();
        if (currentMode === "wall") {
            currentMode = null;
            return;
        }
        currentMode = "wall";
        updateButtonBG(buttonCaseWall);
    }
    function clickCaseEnd() {
        resetButtonsBG();
        if (currentMode === "end") {
            currentMode = null;
            return;
        }
        currentMode = "end";
        updateButtonBG(buttonCaseEnd);
    }
    function clickCaseDefault() {
        resetButtonsBG();
        if (currentMode === "default") {
            currentMode = null;
            return;
        }
        currentMode = "default";
        updateButtonBG(buttonCaseDefault);
    }
    function updateButtonBG(button) {
        button.style.background = "rgb(113, 112, 182)";
    }
    function resetButtonsBG() {
        buttonCaseStart.style.background = "rgb(150, 148, 240)"
        buttonCaseEnd.style.background = "rgb(150, 148, 240)"
        buttonCaseWall.style.background = "rgb(150, 148, 240)"
        buttonCaseDefault.style.background = "rgb(150, 148, 240)"
    }
    function mouseDown() {
        isMouseDown = true;
    }
    function mouseUp() {
        isMouseDown = false;
    }
});